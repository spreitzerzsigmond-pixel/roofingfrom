(function(){
  const cfg = window.__CONFIG__ || {};
  const fmt = new Intl.NumberFormat(cfg.CURRENCY_LOCALE || 'hu-HU');

  const el = {
    form: document.getElementById('quoteForm'),
    area: document.getElementById('area'),
    calcBtn: document.getElementById('calcBtn'),
    price: document.getElementById('price'),
    acceptSection: document.getElementById('acceptSection'),
    acceptBtn: document.getElementById('acceptBtn'),
    calendarSection: document.getElementById('calendarSection'),
    datePicker: document.getElementById('datePicker'),
    timePicker: document.getElementById('timePicker'),
    backBtn: document.getElementById('backBtn'),
    successModal: document.getElementById('successModal'),
    successText: document.getElementById('successText'),
    year: document.getElementById('year'),
    name: document.getElementById('name'),
    email: document.getElementById('email'),
    phone: document.getElementById('phone'),
  };

  // Footer year
  if (el.year) el.year.textContent = new Date().getFullYear();

  // -- Utility
  const clamp = (n, min) => isFinite(n) ? Math.max(n, min) : 0;
  const todayISO = () => new Date().toISOString().split('T')[0];
  const isWeekend = (dateStr) => {
    const d = new Date(dateStr + "T00:00:00");
    const day = d.getDay(); // 0:Sun .. 6:Sat
    return day === 0 || day === 6;
  };

  // Init min date for datePicker
  el.datePicker.setAttribute('min', todayISO());

  // Live calculation handler
  function calculatePrice() {
    const area = clamp(parseFloat(el.area.value), cfg.MIN_AREA || 0);
    if (!area || area < (cfg.MIN_AREA || 0)) {
      el.price.textContent = '—';
      el.acceptSection.classList.add('hide');
      return;
    }
    const base = (cfg.BASE_FEE || 0);
    const price = base + (area * (cfg.PRICE_PER_M2 || 15000));

    // Show a small +/- 10% range to reflect variability
    const low = Math.round(price * 0.9);
    const high = Math.round(price * 1.1);
    el.price.textContent = `${fmt.format(low)} – ${fmt.format(high)} Ft`;

    el.acceptSection.classList.remove('hide');
  }

  // Events
  el.calcBtn.addEventListener('click', calculatePrice);
  el.area.addEventListener('input', () => {
    // auto-update price as user types (without forcing acceptance visibility)
    calculatePrice();
  });

  el.acceptBtn.addEventListener('click', () => {
    el.calendarSection.classList.remove('hide');
    el.datePicker.focus();
  });
  el.backBtn.addEventListener('click', () => {
    el.calendarSection.classList.add('hide');
  });

  // Simple client-side validation and "submission"
  el.form.addEventListener('submit', (e) => {
    e.preventDefault();

    // Basic validity checks
    if (!el.form.checkValidity()) {
      el.form.reportValidity();
      return;
    }
    const date = el.datePicker.value;
    if (!date) {
      alert('Kérlek, válassz időpontot!');
      el.datePicker.focus();
      return;
    }
    if (cfg.BUSINESS_DAYS_ONLY && isWeekend(date)) {
      alert('A kiválasztott nap hétvégére esik. Kérjük, válassz munkanapot!');
      el.datePicker.focus();
      return;
    }

    const payload = {
      name: el.name.value.trim(),
      email: el.email.value.trim(),
      phone: el.phone.value.trim(),
      area: parseFloat(el.area.value),
      estimate: el.price.textContent,
      date: el.datePicker.value,
      timeSlot: el.timePicker.value
    };

    // Here you could send `payload` to your backend via fetch():
    // fetch('/api/quotes', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) })

    // Success modal
    el.successText.textContent = `Köszönjük, ${payload.name}! Foglalásod: ${payload.date} – ${payload.timeSlot}. Hamarosan keresni fogunk!`;
    if (typeof el.successModal.showModal === 'function') {
      el.successModal.showModal();
    } else {
      alert(el.successText.textContent);
    }

    // Reset form to initial state
    el.form.reset();
    el.price.textContent = '—';
    el.acceptSection.classList.add('hide');
    el.calendarSection.classList.add('hide');
    el.datePicker.setAttribute('min', todayISO());
  });
})();